#include "sstream"
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <stdlib.h>

using namespace std;

//For a edge
class Edge {
private:
	int _v;
	int _u;

public:
	Edge(){}

	Edge(int u, int v){
		_u = u;
		_v = v;
	}
	
	int fromVertex(){ 
		return _u;
	}
	
	int toVertex(){ 
		return _v;
	}		
};

//For a bridge block
class C2E{
private:
	vector<int> _V;
	Edge _fa;
	vector<int>	_ExitNodes;
public:
	C2E(){		
	}	
	
	void insert(int v){
		_V.push_back(v);
	}
	
	void insertExistNode(int v){
		_ExitNodes.push_back(v);
	}
	
	void setFather(Edge e){
		_fa = e;
	}
	
	vector<int> getSet(){
		return _V;
	}
	
	vector<int> getExitNodes(){
		return _ExitNodes;
	}
	
	Edge getFather(){
		return _fa;
	}
	
	int getSize(){ 
		return _V.size();
	}
};

//Compute bridge and concerns
class BridgeComputation{
private:
	int _size;
	int *	_low;
	int *	_d;
	int *	_pred;
	int *	_c2e_ind;
	int *	_root;
	
	int _t;
	
	vector<Edge>	BackEdges;
	vector<Edge>	_bridges;
	
	C2E *	c2e;	
	
	vector<int>*	 _A;
	vector<int>*	 _Adj;
	
	vector<int>*	Ch;
	vector<int>	_R;

public:
	BridgeComputation(int size){
		_size = size;
		_low = (int*) malloc (_size * sizeof(int));
		_d = (int*) malloc (_size * sizeof(int));
		_pred = (int*) malloc (_size * sizeof(int));
		_c2e_ind = (int*) malloc (_size * sizeof(int));
		_root = (int*) malloc (_size * sizeof(int));
		for(int i=0;i<_size;i++){
			_low[i]=0;
			_d[i]=0;
			_pred[i]=-1;
			_c2e_ind[i]=-1;
			_root[i]=-1;
		}
	}
	
	void dfs(int u, vector<int> * adj){	
		_t++;
		_low[u] = _t;
		_d[u] = _t;
		
		for(int i = 0; i < adj[u].size(); i++){
			int v = adj[u].at(i);	

			if(_pred[v] == -1){//(u,v) is a tree edges
				_pred[v] = u;
		
				dfs(v,adj);
				if(_low[u] > _low[v]){
					_low[u] = _low[v];
				}
		
			}else{// v has been explored				
				if(v != _pred[u]){// (u,v) is a back edge
					if(_d[u] > _d[v]){						
						if(_low[u] > _low[v]){								
							_low[u] = _low[v];
						}						
						Edge e(u,v);
						BackEdges.push_back(e);

						// update _low for all vertices x from path (u --> v)
						int x = _pred[u];
						while(x != v){
							if(_low[x] > _low[v])
								_low[x] = _low[v];
							x = _pred[x];
						}
					}					
				}
			}
		}		
	}

	void dfs_c2e(int u, vector<int>* adj){		
		if(_low[u] == _d[u]){
			_t++;
			_c2e_ind[u] = _t;	
		}else{
			_c2e_ind[u] = _c2e_ind[_pred[u]];		
		}			
		for(int i=0;i<adj[u].size();i++){
			int v = adj[u].at(i);				
			if(_pred[v] == -1){//(u,v) is a tree edges
				_pred[v] = u;				
				dfs_c2e(v,adj);
			}else{// v has been explored				
			}
		}
	}
	
	void compute(int * V, vector<int>* Adj){	
		int r = 0;	
		_t = 0;
		_pred[r] = r;		
		dfs(r,Adj);
					
		_t = 0;
		for(int i=0;i<_size;i++) _pred[i] = -1;		
		_pred[r] = r;
		dfs_c2e(r,Adj);
				
		c2e = new C2E[_size];	
		for(int i=0;i<_size;i++){
			int v = V[i];		
			int ind = _c2e_ind[v];						
			c2e[ind-1].insert(v);
		}

		for(int i=0;i<_size;i++){
			int v = V[i];		
			int u = _pred[v];
			if(u != v && _low[v] == _d[v]){
				Edge e(v,u);
				_bridges.push_back(e);
			}
		}

		for(int i=0;i<_bridges.size();i++){
			Edge e = _bridges.at(i);		
			int u = e.fromVertex();
			int v = e.toVertex();
			_root[_c2e_ind[u]] = u;						
		}
		_root[_c2e_ind[r]] = r;
				
		_A = new vector<int>[_size];		
		Ch = new vector<int>[_size];
		
		for(int i=0;i<_bridges.size();i++){
			Edge e=_bridges.at(i);		
			int u = e.fromVertex();
			int v = e.toVertex();			
			_A[_root[_c2e_ind[v]]].push_back(u);			
			Ch[v].push_back(u);
			_R.push_back(u);
		}
		_R.push_back(r);		
	}

	//Some get methods	
	C2E * getC2E(){ 
		return c2e;
	}
	
	int getC2E(int v){
		return _c2e_ind[v];
	}
	
	vector<Edge> getBridges(){
		return _bridges;
	}	

	vector<int> getR(){ 
		return _R;
	}

	vector<int> * getC2EAdj(){
		return _A;
	}

	vector<int> * getCh(){ 
		return Ch;
	}

	int* getFathers(){
		return _pred;
	}

	int * getC2EIndices(){
		return _c2e_ind;
	}
};
