#include <ilcplex/ilocplex.h>
#include <stdlib.h>
#include <ctime>
#include <sys/time.h>
#include "ComputeBridgeBlock.cpp"

#define  EPS  1.0E-10
#define  VIRCOST 1.0;
#define	MAXTIME 30 * 60 * 1000 //30 minutes

unsigned st;

ILOSTLBEGIN

static void
	usage (),

	findIsoComp(IloEnv env, const IloArray<IloNumArray> x, 	IloArray<IloIntArray>& isoComponent),	
	

	readUndirectData (char **argv, IloEnv env, IloInt& nNode, 
		IloNumArray& weight, IloNumArray2& cost);

unsigned getTimeInMilli();

ILOLAZYCONSTRAINTCALLBACK1(UserCallback, IloArray<IloNumVarArray>, vars){
	unsigned t2 = getTimeInMilli();
	if(t2 - st > MAXTIME) {
		abort();
		return;
	}
	
	bool opt = false;

	IloEnv env = getEnv();		
	IloInt size = vars.getSize();
	IloInt i, j, k;	

	IloArray<IloNumArray> x = IloArray<IloNumArray>(env, size);
	IloArray<IntegerFeasibilityArray> feas 
		= IloArray<IntegerFeasibilityArray>(env, size);

	for(i = 0; i < size; i++){
		x[i] = IloNumArray(env, size);
		getValues(x[i], vars[i]);			
		
		feas[i] = IntegerFeasibilityArray(env, size);
		getFeasibilities(feas[i], vars[i]);
	}

	bool feaSolution = true;
	for(i = 0; i < size; i++){
		for(j = 0; j < size; j++){
			if(feas[i][j] == Infeasible){
				feaSolution = false;
				//Exit
				i = size; j = size;
			}
		}
	}

	if(feaSolution){
		cout << "............................................................." << endl;
		IloArray<IloIntArray> isoComponent(env);

		//Find isolated components
		findIsoComp(env, x, isoComponent); 

		IloExprArray  lstExpr(env, isoComponent.getSize());
		cout << "Number of isolated components : " << isoComponent.getSize() << endl;
		
		cout << "Print isolated components : ";
		for(i = 0; i < isoComponent.getSize(); i++){
			for(j = 0; j < isoComponent[i].getSize(); j++){
				cout << isoComponent[i][j] << " ";
			}cout << endl;
		}
		
				
		//For each isolated component
		if(isoComponent.getSize() > 1){
			for(i = 0; i < isoComponent.getSize(); i++){
				
				cout << "CONNECTING THIS COMPONENT TO OTHER " << endl;
				vector<int> lstComplementary;
				for(j = 0; j < size; j++){
					bool existed = false;
					for(k = 0; k < isoComponent[i].getSize(); k++){
						if(isoComponent[i][k] == j){
							existed = true;
							k = isoComponent[i].getSize();
						}
					}
					if(!existed){
						lstComplementary.push_back(j);
					}
				}
				
				cout << "Print complementary list : ";
				for(j = 0; j < lstComplementary.size(); j++){
					cout << " " << lstComplementary.at(j) ;
				}cout << endl;
				
				cout << "Print isolated component : ";
				for(j = 0; j < isoComponent[i].getSize(); j++){
					cout << " " << isoComponent[i][j];
				}cout << endl;
				
				IloExpr expr(env, 0);
				for(j = 0; j < lstComplementary.size(); j++){
					for(k = 0; k < isoComponent[i].getSize(); k++){
						expr += vars[lstComplementary.at(j)][isoComponent[i][k]];
					}
				}
				
				try {
					add(expr > 0);				
				}
				catch (...) {				
					throw;
				}		
				
				expr.end();
				
				
				//Add more constraints to remove cycles
				cout << "COMPONENT DOES NOT INCLUDE CYCLES " << endl;
				IloExpr expr2(env, 0);
				for(j = 0; j < isoComponent[i].getSize(); j++){
					for(k = 0; k < isoComponent[i].getSize(); k++){
						expr2 += vars[isoComponent[i][j]][isoComponent[i][k]];
					}
				}
				int N = isoComponent[i].getSize();	
				try{
					add(expr2 <= 2 * (N - 1));
				}catch(...){
					throw;
				}
				expr2.end();
				
			}
		}	
	}
}


int main (int argc, char **argv)
{
	//Starting time
	unsigned t1 = getTimeInMilli();
	st = t1;
	
	IloEnv   env;
	try {
	
		IloInt nNode; //Number of nodes
		IloNumArray2 cost(env); //Cost matrix
		IloNumArray weight(env);//Weight at vertices
		IloInt i, j, k; 

		//Reading data from input file
		readUndirectData(argv, env, nNode, weight, cost);
		
		//Creating file to save result
		ofstream toFile;
		toFile.open(argv[2]);

		//Creating Model
		IloModel model(env, "IWMST");
		IloCplex cplex(model);

		//Variables
		IloArray<IloNumVarArray>  x(env, nNode); 
		for(i = 0; i < nNode; i++) 
			x[i] = IloNumVarArray(env, nNode, 0, 1, ILOINT); //Index of variable spread out from 0 to nNode
		
		IloNumVarArray p(env, nNode, 0, 1, ILOINT);
		
		
		//Objective function
		IloExpr expr(env, 0.0);
		for(i = 0; i < nNode; i++){
			for(j = 0; j < nNode; j++){		
				expr += x[i][j] * cost[i][j];			
			}
			expr += 2.0 * p[i] * weight[i];
		}	
		
		model.add(IloMinimize(env, expr));		
		expr.end();
				
		//Constraint for variable presenting no arc existance
		for(i = 0; i < nNode ; i++) {
			for(j = i ; j < nNode; j++){						
				if(fabs(cost[i][j]) < EPS){
				
					model.add(x[i][j] == 0);
					model.add(x[j][i] == 0);
				}
			}
		}		
		
		for(i = 0; i < nNode - 1; i++){
			for(j = i + 1; j < nNode; j++){
				model.add(x[i][j] == x[j][i]);
			}
		}
		

		for(i = 0; i < nNode; i++){
			IloExpr expr1(env, 0);
			for(j = 0; j < nNode; j++){
				expr1 += x[i][j];
			}
			//model.add(expr1 >= 1);
			IloExpr expr12(env, 0);
			expr12 = expr1 - p[i];
			model.add(1 <= expr12);
			
			IloExpr expr11(env, 0);
			expr11 = expr1 - nNode * p[i];
			
			model.add(expr11 < 2);		
			expr1.end();expr11.end();expr12.end();
		}
		
		IloExpr expr2(env, 0);
		for(i = 0; i < nNode; i++){
			for(j = 0; j < nNode; j++){
				expr2 += x[i][j];
			}
		}
		model.add(expr2 == 2 * (nNode - 1));
		expr2.end();
		
		
		cplex.setParam(IloCplex::MIPSearch, IloCplex::Traditional);
		cplex.setParam(IloCplex::MIPInterval, 1);
		cplex.setParam(IloCplex::EpGap, 0.0);
		cplex.use(UserCallback(env, x));
		cplex.solve();
				
		IloNumArray vals(env);		
		cout << "Solution status = " << cplex.getStatus() << endl;
		cout << "Solution value  = " << cplex.getObjValue() << endl;
		cout << "Solution time = " << cplex.getTime() << endl;
		cout << "Number of nodes = " << cplex.getNnodes() << endl;
		
		unsigned t2 = getTimeInMilli();
		float minValue = 0.0;
		
		if(t2 - t1 < MAXTIME){
			cout << "Values of varible " << endl;
			for(i = 0; i < nNode - 1; i++){
				for(j = i; j < nNode; j++){
					if(cplex.getValue(x[i][j]) > 0){
						cout << "x[" << i << "][" << j << "] = " <<
							cplex.getValue(x[i][j]) << endl;
						minValue += cost[i][j];
						toFile << i + 1 << " - " << j +1 << "; ";
					}
				}
			}
			cout <<endl << "minValue : " << minValue << endl;
			cout << "print P " << endl;
			for(i = 0; i < nNode; i++){
				cout << cplex.getValue(p[i]) << "  ";
				minValue += cplex.getValue(p[i]) * weight[i];
			}
			cout <<endl << "minValue : " << minValue << endl;
			toFile << endl;
			toFile << cplex.getObjValue() << endl;
			toFile << t2 - t1 << endl;
			toFile << cplex.getNnodes();
			
			cout << "Computation time : " << t2 - t1 << endl;
		}
	
	}
	catch (IloException& e) {
		cerr << "Concert exception caught: " << e << endl;
	}
	env.end();

	return 0;
}

static void usage ()
{
	cerr << "Usage: " << endl << "1 : inputFile outputFile nNode sNode tNode 0/1" << endl;
	cerr << "2 : inputFile outputFile nNode 0/1 " << endl;	
	
}//END USAGE


static void readUndirectData (char **argv, IloEnv env, IloInt& nNode, 
	IloNumArray& weight, IloNumArray2& cost)
{
	try
	{
		cout << "Starting reading data from " << argv[1] << endl;
		string line;
		ifstream file(argv[1]);
		if(file.is_open()){	
			
			getline(file, line);//Reading number of vertices and number of edges
			string word;
			stringstream stream(line);
			getline(stream, word, ' '); //Number of vertices
			nNode = atoi(word.c_str()) ;
			
			int nEdge = 0;
			getline(stream, word, ' '); //Number of edges
			nEdge = atoi(word.c_str());
			
			cout << "Number of vertices : " << nNode << ", number of edges : " << nEdge << endl;

			//Creating cost matrix and weight at vertices
			cost = IloNumArray2(env, nNode);
			for(int i = 0; i < nNode; i++) 
				cost[i] = IloNumArray(env, nNode);	
				
			weight = IloNumArray(env, nNode);

			//Reading each arc from file
			int node1; //Begin node of the arc
			int node2; //End node of the arc
			int node;
			double costValue; //Cost of the arc

			while(file.good()) {	
				while(nEdge > 0){
					getline(file, line);
					string word;
					stringstream stream(line);

					getline(stream, word, ';'); //Begin node of the arc
					node1 = atoi(word.c_str()) - 1;
			
					getline(stream, word,';'); //End node of the arc
					node2 = atoi(word.c_str()) - 1;			

					getline(stream, word,';'); //Cost value of the arc
					costValue = atof(word.c_str());				

					if(node1 >= 0 && node1 < nNode &&
						node2 >= 0 && node2 < nNode){
							cost[node1][node2] = costValue; 
							cost[node2][node1] = costValue; 			
						}
					nEdge--;
				}
				
				getline(file, line);
				string word;
				stringstream stream2(line);

				getline(stream2, word, ' '); //Begin node of the arc
				node = atoi(word.c_str()) - 1;	

				getline(stream2, word,' '); //Cost value of the arc
				costValue = atof(word.c_str());	
				
				if(node >= 0 && node < nNode){
					weight[node] = costValue;
				}
			}
		}
		else cout << "Unable to open file" << endl; 		
	}
	catch (...) {
     		 cout << "Reading file exception caught" << endl;
  	} 
}


//Finding isolated components
static void findIsoComp(IloEnv env, const IloArray<IloNumArray> x, 
	IloArray<IloIntArray>& isoComponent)
{
	//cout << "Entering to the function findIsoComp...." << endl;
	IloInt i, j;
	IloInt nNode = x.getSize(); //Size is the number of nodes of the graph
	
	IloIntArray id(env, nNode), sz(env, nNode);	
	for(i = 0; i < nNode; i++){ 
		id[i] = i;
		sz[i] = 1;
	}	

	//Unite these nodes connected to each other
	IloInt rI, rJ;
	for(i = 0; i < nNode; i++){
		for(j = 0; j < nNode; j++){
			if(IloAbs(x[i][j]) > EPS){//Unite two nodes i and j			
				
				rI = i; //Root's ID of i
				while (rI != id[rI]){
					id[rI] = id[id[rI]];
					rI = id[rI]; 
				}

				rJ = j;//Root's ID of j
				while (rJ != id[rJ]){
					id[rJ] = id[id[rJ]];
					rJ = id[rJ]; 
				}
				
				if(sz[rI] < sz[rJ]) {id[rI] = rJ; sz[rJ] += sz[rI];}
				else {id[rJ] = rI; sz[rI] += sz[rJ];}
			}
		}
	}	

	IloIntArray lstRoot(env); //List of rooting nodes

	for(i = 0; i < nNode; i++){
		IloIntArray lstNode(env);

		rI = i;  //Root node of node i
		while (rI != id[rI]){
			id[rI] = id[id[rI]];
			rI = id[rI]; 
		}
				
		//Check that the root of the node i is already in the list of root nodes
		IloBool exiLst = false; 
		for(j = 0; j < lstRoot.getSize(); j++){
			if(rI == lstRoot[j]){
				exiLst = true;
				j = lstRoot.getSize();
			}
		}

		if(!exiLst){ //Root of the node i is not in the list of root nodes			
			lstRoot.add(rI);
			lstNode.add(i);
			isoComponent.add(lstNode);
		}else{ 
			for(j = 0 ; j < lstRoot.getSize(); j++)	{
				if(lstRoot[j] == rI){
					isoComponent[j].add(i);
					j = lstRoot.getSize();
				}
			}
		}		
	}
	
	//Remove element of size 1 in the array isoComponent
	IloBool stopRemove;
	do{
		stopRemove = true;
		for(i = 0; i < isoComponent.getSize(); i++)	{
			if(isoComponent[i].getSize() <= 1){
				isoComponent.remove(i);
				stopRemove = false;
			}
		}	
	}while(!stopRemove);
	
};
unsigned getTimeInMilli(){
	struct timeval tv;
	
	if(gettimeofday(&tv, NULL) != 0){
		return 0;
	}

	return (tv.tv_sec * 1000) + (tv.tv_usec / 1000);
}
